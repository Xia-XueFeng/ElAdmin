// 用户登录
module.exports.login = function(username,password,cb) {
	console.log("登录 %s %s",username,password);
}